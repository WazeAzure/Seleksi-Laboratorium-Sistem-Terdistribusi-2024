function Contact(name, email, cell) {
    this.name = name;
    this.email = email;
    this.cell = cell;
}