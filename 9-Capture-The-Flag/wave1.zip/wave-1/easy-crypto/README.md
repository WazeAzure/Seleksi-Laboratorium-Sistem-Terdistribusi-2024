# README

## Description

Minggu pertama kasih chall yang gampang dulu deh... Moga di akhir ada yang full solve :D
