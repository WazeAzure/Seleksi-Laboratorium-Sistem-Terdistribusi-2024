# README

## Description

Easy flag checker! Just that the file are stripped, so it's a _little_ harder...
