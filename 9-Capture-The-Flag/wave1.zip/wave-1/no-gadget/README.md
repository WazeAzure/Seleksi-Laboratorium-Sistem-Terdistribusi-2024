# README

Goal: open shell

Restriction:

- Use the given libc and linker file
- libc address must be resolved first

## Description

No gadgets??? _insert megamind boom sound effect_
