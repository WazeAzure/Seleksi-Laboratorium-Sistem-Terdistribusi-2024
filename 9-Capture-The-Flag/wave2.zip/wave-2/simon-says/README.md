# README

Goal: open shell

Restriction:

- Use the given libc file
- libc address must be resolved first
- elf address must be resolved first

## Description

I'll give you an easy format string challenge, but with a size limit!!!
