# README

## Description

I know that this cryptosystem is broken by Lagarias and Odlyzko, but who says that can't I use it with larger density?
